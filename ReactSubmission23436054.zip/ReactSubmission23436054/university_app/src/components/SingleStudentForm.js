import { useState } from "react";
import { useNavigate } from "react-router-dom";

function SingleStudentForm() {
    const [student_id, setStudentId] = useState("");
    const navigate = useNavigate();

    const handleChange = (e) => {
        setStudentId(e.target.value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (student_id) {
            navigate("/singlestudent", { state: { student_id } });
        }
    };

    return (
		<form onSubmit={handleSubmit} className="navbar-custom p-4 rounded shadow-lg w-50">
			<div className="mb-3">
				<label for="student_id" className="form-label text-white">Student ID</label>
				<input 
					type="text" 
					name="student_id" 
					id="student_id" 
					value={student_id} 
					onChange={handleChange} 
					className="form-control"
					placeholder="Enter valid student ID"
					maxLength={8}
					minLength={8}
					required
				/>
			</div>

			<div className="text-center">
				<button type="submit" className="btn btn-warning text-white px-4 py-2 fw-bold">View Student</button>
			</div>
					
        </form>
    );
}

export default SingleStudentForm;
