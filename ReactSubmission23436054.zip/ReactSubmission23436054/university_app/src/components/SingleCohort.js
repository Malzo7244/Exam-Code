import { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";

const SingleCohort = () => {
	const location = useLocation();
	const { id } = location.state
	const [students, setStudents] = useState([]);

	useEffect(() => {
	if (id) {
		fetch(`http://127.0.0.1:8000/api/student/?cohort=${id}`)
		.then((res) => res.json())
		.then((data) => setStudents(data))
	}
	}, [id]);

	const displayStudents = () => {
		return students.map((student) => (
			<li key={student.student_id}>
				<Link to="/singlestudent" state={{ student_id: student.student_id }}className="display-6 text-white text-decoration-none">
					{student.first_name} {student.last_name} - <span className="text-warning">{student.student_id}</span>
				</Link>
			</li>
			));
		}

	return (
	<div>
		<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
			<h1 className="display-3 fw-bold text-white text-center mb-5">Students in {id}</h1>
			<p className="display-6 text-white mb-5 text-center">Click to view an individual student.</p>
			<div className="text-center mb-2">
				<Link to="/cohortmodules" state={{ id: id }} className="btn btn-warning text-white">Modules for {id}</Link>
			</div>
		</div>
		<ul>{displayStudents()}</ul>
	</div>
  );
};

export default SingleCohort;