import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function CohortsFetcher() {
  const [cohorts, setCohorts] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/cohort/")
      .then((resp) => resp.json())
      .then((data) => setCohorts(data))
  }, []);

  const displayCohorts = () => {
    return cohorts.map((cohort) => (
      <li key={cohort.id}>
        <Link to="/singlecohort" state={{ id: cohort.id }} className="display-6 text-white text-decoration-none">
          <p>{cohort.name} <span className="text-warning">({cohort.id})</span></p>
        </Link>
      </li>
    ));
  };

  return (
    <div>
      <ul>{displayCohorts()}</ul>
    </div>
  );
}

export default CohortsFetcher;
