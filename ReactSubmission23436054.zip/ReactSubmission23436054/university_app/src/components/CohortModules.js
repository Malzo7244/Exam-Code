import { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";

const CohortModules = () => {
    const location = useLocation();
    const { id } = location.state;
    const [modules, setModules] = useState([]);

    useEffect(() => {
        if (id) {
            fetch("http://127.0.0.1:8000/api/module/")
                .then((res) => res.json())
                .then((data) => {
                    const filteredModules = data.filter((module) =>
                        module.delivered_to.some(url => url.endsWith("/" + id + "/"))
                    );
                    setModules(filteredModules);
                });
        }
    }, [id]);

    const displayModules = () => {
        return modules.map((module) => (
            <li key={module.code}>
                <Link to="/singlemodule" state={{ code: module.code }}className="display-6 text-white text-decoration-none">
					<span className="text-warning">{module.code}</span> - {module.full_name}
                </Link>
            </li>
        ));
    };

	return (
		<div>
			<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
				<h1 className="display-3 fw-bold text-white text-center mb-5">Modules delivered to {id}</h1>
				<p className="display-6 text-white mb-5 text-center">Click to view an individual module.</p>
			</div>
			<ul>{displayModules()}</ul>
		</div>
    );
};

export default CohortModules;
