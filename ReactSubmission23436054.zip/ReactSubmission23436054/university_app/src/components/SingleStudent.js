import { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";
import "../App.css";

const SingleStudent = () => {
	const location = useLocation();
	const { student_id } = location.state
	const [student, setStudent] = useState({});
	const [grades, setGrades] = useState([]);
	const [modules, setModules] = useState([]);

	useEffect(() => {
		if (student_id) {
		fetch(`http://127.0.0.1:8000/api/student/${student_id}`)
			.then((res) => res.json())
			.then((data) => setStudent(data))
	}
	}, [student_id]);

	useEffect(() => {
		if (student_id) {
		  fetch(`http://127.0.0.1:8000/api/grade/?student=${student_id}`)
			.then((res) => res.json())
			.then((data) => {
			  setGrades(data);
			})
		}
	  }, [student_id]);

	useEffect(() => {
		if (student && student.cohort) {
			const cohort_id = student.cohort.split('/').filter(Boolean).pop();
	
			fetch(`http://127.0.0.1:8000/api/module/`)
				.then(res => res.json())
				.then(data => {
					const Modules = [];
	
					data.forEach(module => {
						module.delivered_to.forEach(cohortUrl => {
							const moduleCohortId = cohortUrl.split('/').filter(Boolean).pop();
							if (moduleCohortId === cohort_id) {
								Modules.push(module);
							}
						});
					});
	
					setModules(Modules);
				});
		}
	}, [student]);


	const displayStudent = () => {
		if (!student || !student.cohort) {
			return <p>Loading student details...</p>;
		}
	
		return (
			<div>
				<div className="container py-5 d-flex flex-column justify-content-center align-items-center"></div>
					<h1 className="display-3 fw-bold text-white text-center mb-5">{student.first_name} {student.last_name}</h1>
					<ul className="list-unstyled text-center">
						<li className="display-6 text-white mb-1 text-center"><span className="text-warning">Student Number:</span> {student.student_id}</li>
						<li className="display-6 text-white mb-1 text-center"><span className="text-warning">Email:</span> {student.email}</li>
						<li className="display-6 text-white mb-5 text-center"><span className="text-warning">Cohort:</span> {student.cohort.split("/").filter(Boolean).pop()}</li>
					</ul>
			</div>
		);
	};

	const displayModules = () => {
		return (
		<div>
			<h3 className="display-6 fw-bold text-white">Modules {student.first_name} is registered for:</h3>
			<ul>
				{modules.map((module) => (
				<li key={module.code}>
					<Link to="/singlemodule" state={{ code: module.code }} className="display-6 text-white text-decoration-none">
						{module.full_name} - <span className="text-warning">{module.code}</span>
					</Link>
				</li>
			))}
		</ul>
		</div>
		);
	};

	const displayGrades = () => {
		const gradedModuleCodes = grades.map((grade) => grade.module.split("/").filter(Boolean).pop());

		// Filter modules that don't have a grade assigned
		const ungradedModules = modules.filter((module) => !gradedModuleCodes.includes(module.code));

		let cohort_id = null;
		if (student && student.cohort) {
			cohort_id = student.cohort.split('/').filter(Boolean).pop();
		}

		return (
			<div>
				<h3 className="display-6 fw-bold text-white mb-5">
					{student.first_name}'s grades this year:
				</h3>
				<div className="container">
					<div className="row gy-3">

						{/* Display modules that have been assigned a grade */}
						{grades.map((grade) => {
							const moduleCode = grade.module.split("/").filter(Boolean).pop();

							return (
								<div key={grade.id} className="col-md-6 col-lg-4">
									<div className="p-3 border rounded navbar-custom text-white">
										<h4 className="fw-bold text-warning">Module: {moduleCode}</h4>
										<p>CA Mark: {grade.ca_mark}</p>
										<p>Exam Mark: {grade.exam_mark}</p>
										<p className="fw-bold">Total Grade: {grade.total_grade}</p>
										<Link
											to="/setgrade"
											state={{ student_id: student.student_id, module_code: moduleCode }}
											className="btn btn-warning text-white fw-bold"
										>
											Set Grade
										</Link>
									</div>
								</div>
							);
						})}
						
						{/* Display modules that don't have a grade assigned to them yet */}
						{ungradedModules.map((module) => (
							<div key={module.code} className="col-md-6 col-lg-4">
								<div className="p-3 border rounded navbar-custom text-white">
									<h4 className="fw-bold text-warning">Module: {module.code}</h4>
									<p className="fw-bold">No grade assigned</p>
									<Link
										to="/creategrade"
										state={{ student_id: student.student_id, module_code: module.code, cohort_id: cohort_id }}
										className="btn btn-warning text-white fw-bold"
									>
										Create Grade
									</Link>
								</div>
							</div>
						))}
					</div>
				</div>
			</div>
		);
};



	return (
	<div>
		{displayStudent()}
		{displayModules()}
		{displayGrades()}
	</div>
  );
};

export default SingleStudent;
