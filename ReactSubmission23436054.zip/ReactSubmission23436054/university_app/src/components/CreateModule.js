import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Select from "react-select"; // Imported for cleaner cohort selection styling

function CreateModule() {
	const [cohorts, setCohorts] = useState([]);
    const [formData, setFormData] = useState({
        code: "",
        full_name: "",
        delivered_to: [],
        ca_split: 0
    });

    const navigate = useNavigate();

    useEffect(() => {
        fetch("http://127.0.0.1:8000/api/cohort/")
            .then(res => res.json())
            .then(data => setCohorts(data));
    }, []);

    const handleSelectChange = (selectedOptions) => {
        setFormData({
            ...formData,
            delivered_to: selectedOptions.map(option => option.value)
        });
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        fetch('http://127.0.0.1:8000/api/module/', {
            method: 'POST',
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(formData)
        })
        .then(resp => resp.json())
        .then(() => {
            navigate("/modules");
        });
    };

    return (
        <div className="container py-5 d-flex flex-column align-items-center">
            <h1 className="display-3 fw-bold text-white text-center mb-4">Create New Module</h1>
            <p className="display-6 text-white text-center mb-4">Please enter a code, name, CA split and select the cohorts it will be delivered to.</p>
            <form onSubmit={handleSubmit} className="navbar-custom p-4 rounded shadow-lg w-50">
                <div className="mb-3">
                    <label htmlFor="code" className="form-label text-white">Module Code</label>
                    <input 
                        type="text" 
                        name="code" 
                        id="code" 
                        value={formData.code} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter module code"
                        maxLength={5}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="full_name" className="form-label text-white">Module Name</label>
                    <input 
                        type="text" 
                        name="full_name" 
                        id="full_name" 
                        value={formData.full_name} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter full module name"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="ca_split" className="form-label text-white">CA Split</label>
                    <input 
                        type="number" 
                        name="ca_split" 
                        id="ca_split" 
                        value={formData.ca_split} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter CA split"
                        min="0"
                        max="100"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label className="form-label text-white">Cohorts Delivered To</label>
                    <Select
                        isMulti
                        options={cohorts.map(cohort => ({
                            value: `http://localhost:8000/api/cohort/${cohort.id}/`,
                            label: cohort.name
                        }))}
                        onChange={handleSelectChange}
                        className="basic-multi-select"
                        classNamePrefix="select"
                    />
                </div>

                <div className="text-center">
                    <button type="submit" className="btn btn-warning text-white px-4 py-2 fw-bold">Add Module</button>
                </div>
            </form>
        </div>
    );
}

export default CreateModule;
