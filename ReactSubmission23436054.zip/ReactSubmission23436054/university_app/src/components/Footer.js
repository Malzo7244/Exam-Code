import React from 'react';

function Footer() {
    return (
        <footer className="navbar-custom text-white text-center py-2 mt-5">
            <p className="small">Malachi Byrne, 23436054, COMSCI2, CSC1040, Assignment 2</p>
        </footer>
    );
}

export default Footer;
