import { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";

const ModuleStudents = () => {
    const location = useLocation();
    const { delivered_to } = location.state;

    const [students, setStudents] = useState([]);

    useEffect(() => {
        if (delivered_to && delivered_to.length > 0) {
            delivered_to.forEach(cohortUrl => {
                const cohortId = cohortUrl.split('/').filter(Boolean).pop();

                fetch(`http://127.0.0.1:8000/api/student/?cohort=${cohortId}`)
                    .then(res => res.json())
                    .then(data => setStudents((prevStudents) => [...prevStudents, ...data]));
            });
        }
    }, [delivered_to]);

	const displayStudents = () => {
		return students.map((student) => (
		  <li key={student.id}>
			<Link to="/singlestudent" state={{ student_id: student.student_id }} className="display-6 text-white text-decoration-none">
				{student.first_name} {student.last_name} - <span className="text-warning">({student.student_id})</span>
			</Link>
		  </li>
		));
	  };

	return (
		<div>
			<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
				<h1 className="display-3 fw-bold text-white text-center mb-5">Students in Selected Module</h1>
				<p className="display-6 text-white mb-5 text-center">Click to view an individual student.</p>
			</div>
			<ul>{displayStudents()}</ul>
		</div>
	  );
};

export default ModuleStudents;
