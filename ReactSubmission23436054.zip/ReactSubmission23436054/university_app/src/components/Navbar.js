import { NavLink } from "react-router-dom";
import logo from '../logo.png';
import '../App.css';

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark navbar-custom">
      <div className="d-flex w-100">
        <NavLink className="navbar-brand" to="/">
          <img src={logo} alt="Logo" style={{ width: '80px' }} />
        </NavLink>
        
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item me-5">
              <NavLink className="nav-link text-warning" to="/degrees" activeClassName="active-link">Degrees</NavLink>
            </li>
            <li className="nav-item me-5">
              <NavLink className="nav-link text-warning" to="/cohorts" activeClassName="active-link">Cohorts</NavLink>
            </li>
            <li className="nav-item me-5">
              <NavLink className="nav-link text-warning" to="/modules" activeClassName="active-link">Modules</NavLink>
            </li>
            <li className="nav-item me-5">
              <NavLink className="nav-link text-warning" to="/students" activeClassName="active-link">Students</NavLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
