import { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";

const SingleDegree = () => {
	const location = useLocation();
	const { shortcode } = location.state
	const [cohorts, setCohorts] = useState([]);

	useEffect(() => {
	if (shortcode) {
		fetch(`http://127.0.0.1:8000/api/cohort/?degree=${shortcode}`)
		.then((res) => res.json())
		.then((data) => setCohorts(data))
	}
	}, [shortcode]);
	
	const displayCohorts = () => {
		return cohorts.map((cohort) => (
			<li key={cohort.id}>
				<Link to="/singlecohort" state={{ id: cohort.id }}className="display-6 text-white text-decoration-none">
					{cohort.name} - <span className="text-warning">({shortcode})</span>
				</Link>
			</li>
			));
		}

	return (
		<div>
			<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
				<h1 className="display-3 fw-bold text-white text-center mb-5">Cohorts for {shortcode}</h1>
				<p className="display-6 text-white mb-5 text-center">Click to view all students in a cohort.</p>
			</div>
			<ul>{displayCohorts()}</ul>
		</div>
	);
};

export default SingleDegree;
