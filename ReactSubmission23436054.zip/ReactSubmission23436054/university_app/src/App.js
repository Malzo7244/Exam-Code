import { Route, Routes, BrowserRouter } from 'react-router-dom';
import './App.css';

import Home from './pages/Home'
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Degree-related imports
import Degrees from './pages/Degrees';
import SingleDegree from "./components/SingleDegree";
import CreateDegree from "./components/CreateDegree";

// Cohort-related imports
import Cohorts from './pages/Cohorts';
import SingleCohort from "./components/SingleCohort";
import CreateCohort from './components/CreateCohort';

// Module-related imports
import Modules from './pages/Modules';
import SingleModule from './components/SingleModule';
import CohortModules from './components/CohortModules';
import ModuleStudents from './components/ModuleStudents';
import CreateModule from './components/CreateModule';

// Student-related imports
import Students from './pages/Students';
import SingleStudent from './components/SingleStudent';
import CreateStudent from './components/CreateStudent';
import SingleStudentForm from './components/SingleStudentForm';
import SetGrade from './components/SetGrade';
import CreateGrade from './components/CreateGrade';

function App() {
	return (
		<BrowserRouter>
			<Navbar />
			
			<Routes>
				<Route path="/" element={<Home />} />

				{/* Degree-related routes */}
				<Route path="/degrees" element={<Degrees />} />
				<Route path="/singledegree" element={<SingleDegree />} />
				<Route path="/createdegree" element={<CreateDegree />} />

				{/* Cohort-related routes */}
				<Route path="/cohorts" element={<Cohorts />} />
				<Route path="/singlecohort" element={<SingleCohort />} />
				<Route path="/createcohort" element={<CreateCohort />} />
				<Route path="/cohortmodules" element={<CohortModules />} />

				{/* Module-related routes */}
				<Route path="/modules" element={<Modules />} />
				<Route path="/singlemodule" element={<SingleModule />} />
				<Route path="/modulestudents" element={<ModuleStudents />} />
				<Route path="/createmodule" element={<CreateModule />} />

				{/* Student-related routes */}
				<Route path="/students" element={<Students />} />
				<Route path="/singlestudentform" element={<SingleStudentForm />} />
				<Route path="/createstudent" element={<CreateStudent />} />
				<Route path="/singlestudent" element={<SingleStudent />} />
				<Route path="/setgrade" element={<SetGrade />} />
				<Route path="/creategrade" element={<CreateGrade />} />
			</Routes>

			<Footer />
		</BrowserRouter>
	);
}

export default App;
