import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function ModuleFetcher() {
  const [modules, setModules] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/module/")
      .then((resp) => resp.json())
      .then((data) => setModules(data))
  }, []);

  const displayModules = () => {
    return modules.map((module) => (
      <li key={module.code}>
        <Link to="/singlemodule" state={{ code: module.code }} className="display-6 text-white text-decoration-none">
        	<p>{module.full_name} <span className="text-warning">({module.code})</span></p>
        </Link>
      </li>
    ));
  };

  return (
    <div>
      <ul>{displayModules()}</ul>
    </div>
  );
}

export default ModuleFetcher;
