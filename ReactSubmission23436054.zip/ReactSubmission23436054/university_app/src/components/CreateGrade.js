import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "../App.css";

function CreateGrade() {
	const location = useLocation();
    const { student_id, module_code, cohort_id} = location.state;
    const [formData, setFormData] = useState({
        module: "http://localhost:8000/api/module/" + module_code + "/",
        ca_mark: 0,
		exam_mark: 0,
		cohort: "http://localhost:8000/api/cohort/" + cohort_id + "/",
		student: "http://localhost:8000/api/student/" + student_id + "/"
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: Number(e.target.value) // Ensure input is stored as a number
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        fetch('http://127.0.0.1:8000/api/grade/', {
            method: 'POST',
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(formData)
        })
        .then(resp => resp.json())
        .then(() => {
            navigate("/singlestudent", { state: { student_id } });
        });
    };

    return (
        <div className="container py-5 d-flex flex-column align-items-center">
            <h1 className="display-3 fw-bold text-white text-center mb-4">Create New Grade</h1>
            <p className="display-6 text-white text-center mb-4">Please enter a CA and Exam Mark.</p>

			<form onSubmit={handleSubmit} className="navbar-custom p-4 rounded shadow-lg w-50">
                <div className="mb-3">
                    <label htmlFor="ca_mark" className="form-label text-white">CA Mark</label>
                    <input 
                        type="number" 
                        name="ca_mark" 
                        id="ca_mark" 
                        value={formData.ca_mark} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter continuous assessment mark"
                        min="0"
                        max="100"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="exam_mark" className="form-label text-white">Exam Mark</label>
                    <input 
                        type="number" 
                        name="exam_mark" 
                        id="exam_mark" 
                        value={formData.exam_mark} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter exam mark"
                        min="0"
                        max="100"
                        required
                    />
                </div>

                <div className="text-center">
                    <button type="submit" className="btn btn-warning text-white px-4 py-2 fw-bold">Set Grade</button>
                </div>
            </form>
        </div>
    );
}

export default CreateGrade;
