import { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";

const SingleModule = () => {
    const location = useLocation();
    const { code } = location.state;
    const [module, setModule] = useState(null);

    useEffect(() => {
        if (code) {
            fetch(`http://127.0.0.1:8000/api/module/${code}/`)
                .then((res) => res.json())
                .then((data) => setModule(data));
        }
    }, [code]);

	if (!module) {
        return <p>Loading module details...</p>;  // Avoids trying to split a null object while the data is loading
    }

	const displayModules = () => {
		return (
			<div>
				<h3 className="display-6 fw-bold text-white">Cohorts delivered to:</h3>
				<ul>
					{module.delivered_to.map((cohortUrl, index) => {
						const cohortId = cohortUrl.split('/').filter(Boolean).pop();
						return (
							<li key={index}>
								<Link to="/singlecohort" state={{ id: cohortId }} className="display-6 text-white text-decoration-none">
									{cohortId}
								</Link>
							</li>
						);
					})}
				</ul>
			</div>
		);
	}
	

  return (
	<div>
		<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
			<h1 className="display-3 fw-bold text-white text-center mb-5">{module.full_name} - {module.code}</h1>
			<p className="display-6 text-white mb-2 text-center">CA Split: {module.ca_split}</p>
			<p className="display-6 text-white mb-5 text-center">Click to view an individual module.</p>
			<div className="text-center mb-2">
				<Link to="/modulestudents" className="btn btn-warning text-white" state={{ delivered_to: module.delivered_to }}>View students in {module.code}</Link>
			</div>
		</div>
		{displayModules()}
	</div>
  );
};

export default SingleModule;
