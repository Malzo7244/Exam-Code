import CohortsFetcher from "../components/CohortsFetcher";
import { Link } from "react-router-dom";

function Cohorts() {
    return (
		<div>
			<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
				<h1 className="display-1 fw-bold text-white text-center mb-5">All Cohorts</h1>
				<p className="display-6 text-white mb-5 text-center">Click to view all students in a cohort.</p>
				<div className="text-center mb-2">
					<Link to="/createcohort" className="btn btn-warning text-white">Create Cohort</Link>
				</div>
			</div>
			<CohortsFetcher />
		</div>
    );
}

export default Cohorts;

