import { Link } from "react-router-dom";

function Home() {
    return (
        <div className="d-flex flex-column justify-content-center align-items-center min-vh-100 text-center">
            <h1 className="display-1 fw-bold text-white mb-4">Welcome to the DCU Registry Application</h1>
            <p className="display-6 text-white mb-4">
                View and create
                <Link to="/degrees" className="text-warning text-decoration-none"> degrees, </Link>
                <Link to="/cohorts" className="text-warning text-decoration-none">cohorts, </Link>
                <Link to="/modules" className="text-warning text-decoration-none">modules, </Link>
                and <Link to="/students" className="text-warning text-decoration-none">students.</Link>
            </p>
        </div>
    );
}

export default Home;
