import DegreesFetcher from "../components/DegreesFetcher";
import { Link } from "react-router-dom";

function Degrees() {
    return (
		<div>
			<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
			<h1 className="display-1 fw-bold text-white text-center mb-5">All Degrees</h1>
			<p className="display-6 text-white mb-5 text-center">Click to view all cohorts in a degree.</p>
				<div className="text-center mb-2">
					<Link to="/createdegree" className="btn btn-warning text-white">Create Degree</Link>
				</div>
			</div>
			<DegreesFetcher />
		</div>
    );
}

export default Degrees;
