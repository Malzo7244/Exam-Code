import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css";

function CreateDegree() {
    const [formData, setFormData] = useState({
        full_name: "",
        shortcode: ""
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        fetch('http://127.0.0.1:8000/api/degree/', {
            method: 'POST',
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(formData)
        })
        .then(resp => resp.json())
        .then(() => {
            navigate("/degrees");
        });
    };

    return (
        <div className="container py-5 d-flex flex-column align-items-center">
            <h1 className="display-3 fw-bold text-white text-center mb-4">Create New Degree</h1>
            <p className="display-6 text-white text-center mb-4">Please enter a name and shortcode.</p>

            <form onSubmit={handleSubmit} className="navbar-custom p-4 rounded shadow-lg w-50">
                <div className="mb-3">
                    <label for="full_name" className="form-label text-white">Full Degree Name</label>
                    <input 
                        type="text" 
                        name="full_name" 
                        id="full_name" 
                        value={formData.full_name} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter degree name"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label for="shortcode" className="form-label text-white">Shortcode</label>
                    <input 
                        type="text" 
                        name="shortcode" 
                        id="shortcode" 
                        value={formData.shortcode} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter shortcode"
                        required
                    />
                </div>

                <div className="text-center">
                    <button type="submit" className="btn btn-warning text-white px-4 py-2 fw-bold">Add Degree</button>
                </div>
            </form>
        </div>
    );
}

export default CreateDegree;
