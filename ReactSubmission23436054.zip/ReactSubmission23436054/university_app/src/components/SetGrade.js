import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";

function SetGrade() {
    const location = useLocation();
    const { student_id, module_code } = location.state;
    const [gradeId, setGradeId] = useState(null);
    const [formData, setFormData] = useState({
        ca_mark: 0,
        exam_mark: 0
    });

    const navigate = useNavigate();

    useEffect(() => {
        if (student_id && module_code) {
            fetch(`http://127.0.0.1:8000/api/grade/?student=${student_id}&module=${module_code}`)
                .then((response) => response.json())
                .then((data) => { // We will receive a JSON object, so the grade object must be the first element in the object.
                    if (data.length > 0) {
                        const grade = data[0];
                        setGradeId(grade.id);
                        setFormData({
                            ca_mark: grade.ca_mark,
                            exam_mark: grade.exam_mark
                        });
                    }
                });
        }
    }, [student_id, module_code]);

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: Number(e.target.value) // Ensure input is stored as a number
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const updatedData = {
            ca_mark: formData.ca_mark,
            exam_mark: formData.exam_mark
        };

        fetch(`http://127.0.0.1:8000/api/grade/${gradeId}/`, {
            method: "PATCH", // Since we are updating the grade we use PATCH rather than POST
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(updatedData)
        })
        .then((response) => response.json())
        .then(() => {
            navigate("/singlestudent", { state: { student_id } });
        })
    };

    return (
        <div className="container py-5 d-flex flex-column align-items-center">
            <h1 className="display-3 fw-bold text-white text-center mb-4">Set Grade</h1>
            <p className="display-6 text-white text-center mb-4">Please enter a new CA and Exam Mark.</p>

            <form onSubmit={handleSubmit} className="navbar-custom p-4 rounded shadow-lg w-50">
                <div className="mb-3">
                    <label htmlFor="ca_mark" className="form-label text-white">CA Mark</label>
                    <input 
                        type="number" 
                        name="ca_mark" 
                        id="ca_mark" 
                        value={formData.ca_mark} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter continuous assessment mark"
                        min="0"
                        max="100"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="exam_mark" className="form-label text-white">Exam Mark</label>
                    <input 
                        type="number" 
                        name="exam_mark" 
                        id="exam_mark" 
                        value={formData.exam_mark} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter exam mark"
                        min="0"
                        max="100"
                        required
                    />
                </div>

                <div className="text-center">
                    <button type="submit" className="btn btn-warning text-white px-4 py-2 fw-bold">Update Grade</button>
                </div>
            </form>
        </div>
    );

	
}

export default SetGrade;
