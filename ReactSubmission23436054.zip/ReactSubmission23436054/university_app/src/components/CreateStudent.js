import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

function CreateStudent(){
	const [cohorts, setCohorts] = useState([]);
    const [formData, setFormData] = useState({
        "student_id": "",
        "first_name": "",
        "last_name": "",
		"cohort": "",
    });

	const navigate = useNavigate();

    useEffect(() => {
        fetch("http://127.0.0.1:8000/api/cohort/")
            .then(res => res.json())
            .then(data => setCohorts(data))
    }, []);

    const handleChange = (e) =>{
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        })
    }

    const handleSubmit = (e) =>{
        e.preventDefault();
        fetch("http://127.0.0.1:8000/api/student/", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify({
                ...formData,
            })
        })
        .then(resp => resp.json())
        .then(data => {
            navigate("/singlestudent", { state: { student_id: data.student_id } });
        })
    }

    return(
		<div className="container py-5 d-flex flex-column align-items-center">
			<h1 className="display-3 fw-bold text-white text-center mb-4">Create New Student</h1>
			<p className="display-6 text-white text-center mb-4">Please enter an ID, first name, last name and cohort.</p>

			<form onSubmit={handleSubmit} className="navbar-custom p-4 rounded shadow-lg w-50">
                <div className="mb-3">
                    <label for="student_id" className="form-label text-white">Student ID</label>
                    <input 
                        type="text" 
                        name="student_id" 
                        id="student_id" 
                        value={formData.student_id} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter a valid student ID"
						maxlength={8}
						minlength={8}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label for="first_name" className="form-label text-white">First name</label>
                    <input 
                        type="text" 
                        name="first_name" 
                        id="first_name" 
                        value={formData.first_name} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter first name"
                        required
                    />
                </div>

				<div className="mb-3">
                    <label for="last_name" className="form-label text-white">Last name</label>
                    <input 
                        type="text" 
                        name="last_name" 
                        id="last_name" 
                        value={formData.last_name} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter last name"
                        required
                    />
                </div>

				<div className="mb-3">
                    <label for="cohort" className="form-label text-white">Cohort</label>
                    <select 
                        name="cohort" 
                        id="cohort" 
                        value={formData.cohort} 
                        onChange={handleChange} 
                        className="form-select"
                        required
					>
						<option value="">-- Select Cohort --</option>
						{cohorts.map((cohort) => (
							<option key={cohort.id} value={`http://127.0.0.1:8000/api/cohort/${cohort.id}/`}>{cohort.name}</option>
						))}
					</select>
                </div>

                <div className="text-center">
                    <button type="submit" className="btn btn-warning text-white px-4 py-2 fw-bold">Add Student</button>
                </div>
            </form>
        </div>
    )
}

export default CreateStudent;