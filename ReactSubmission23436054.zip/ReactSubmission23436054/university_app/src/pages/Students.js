import { Link } from "react-router-dom";
import SingleStudentForm from "../components/SingleStudentForm";

function Students() {
    return (
        <div>
			<div className="container py-5 d-flex flex-column justify-content-center align-items-center">
				<h1 className="display-1 fw-bold text-white text-center mb-5">Students</h1>
            	<p className="display-6 text-white mb-5 text-center">Enter a student number to view that student, or create a student with the button below.</p>
				<div className="text-center mb-5">
					<Link to="/createstudent" className="btn btn-warning text-white">Create Student</Link>
				</div>
				<SingleStudentForm />
				</div>
        </div>
    );

}
export default Students;