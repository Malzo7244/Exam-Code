import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

function CreateCohort(){
    const [formData, setFormData] = useState({
        "id": "",
        "year": "",
        "degree": ""
    });

    const [degrees, setDegrees] = useState([]);
	const navigate = useNavigate();

    useEffect(() => {
        fetch("http://127.0.0.1:8000/api/degree/")
            .then(res => res.json())
            .then(data => setDegrees(data))
    }, []);

    const handleChange = (e) =>{
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        })
    }

    const handleSubmit = (e) =>{
        e.preventDefault();

		const updatedData = {
			...formData,
			year: Number(formData.year)
		};

        fetch("http://127.0.0.1:8000/api/cohort/", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify({
                ...updatedData,
            })
        })
        .then(resp => resp.json())
        .then(data => {
            navigate("/cohorts");
        })
    }

	return (
        <div className="container py-5 d-flex flex-column align-items-center">
            <h1 className="display-3 fw-bold text-white text-center mb-4">Create New Cohort</h1>
            <p className="display-6 text-white text-center mb-4">Please enter an ID, year and degree.</p>

            <form onSubmit={handleSubmit} className="navbar-custom p-4 rounded shadow-lg w-50">
                <div className="mb-3">
                    <label for="id" className="form-label text-white">Cohort ID</label>
                    <input 
                        type="text" 
                        name="id" 
                        id="id" 
                        value={formData.id} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter ID"
                        required
                    />
                </div>

                <div className="mb-3">
                    <label for="year" className="form-label text-white">Year</label>
                    <input 
                        type="number" 
                        name="year" 
                        id="year" 
                        value={formData.year} 
                        onChange={handleChange} 
                        className="form-control"
                        placeholder="Enter year of study"
						min="1"
                        required
                    />
                </div>

				<div className="mb-3">
                    <label htmlFor="degree" className="form-label text-white">Degree</label>
                    <select 
                        name="degree" 
                        id="degree" 
                        value={formData.degree} 
                        onChange={handleChange} 
                        className="form-select"
                        required
					>
                        <option value="">-- Select Degree --</option>
                        {degrees.map((degree) => (
                            <option key={degree.id} value={`http://127.0.0.1:8000/api/degree/${degree.shortcode}/`}>{degree.full_name}</option>
                        ))}
                    </select>
                </div>

                <div className="text-center">
                    <button type="submit" className="btn btn-warning text-white px-4 py-2 fw-bold">Add Cohort</button>
                </div>
            </form>
        </div>
    );
}

export default CreateCohort;
