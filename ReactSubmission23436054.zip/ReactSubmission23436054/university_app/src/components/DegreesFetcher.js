import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function DegreesFetcher() {
  const [degrees, setDegrees] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/degree/")
      .then((resp) => resp.json())
      .then((data) => setDegrees(data));
  }, []);

  const displayDegrees = () => {
    return degrees.map((degree) => (
      <li key={degree.shortcode}>
        <Link to="/singledegree" state={{ shortcode: degree.shortcode }} className="display-6 text-white text-decoration-none">
            {degree.full_name} <span className="text-warning">({degree.shortcode})</span>
        </Link>
      </li>
    ));
  };

  return (
    <div>
      <ul>
        {displayDegrees()}
      </ul>
    </div>
  );
}

export default DegreesFetcher;
